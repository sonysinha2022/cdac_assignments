using HRAPP.Entities;

namespace HRAPP.Views;

public interface IView{
    public void Render();
}