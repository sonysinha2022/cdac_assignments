const express=require('express')
let myrouter=express.Router()

const connection=require('../dbs/database')


myrouter.get('/index',(req,resp)=>{
   
    resp.send('index')

})

myrouter.get("/display",(req,resp)=>{
    connection.query("select * from Employee",(err,data,fileds)=>{
        if (err) {
            resp.status(404).send("page not found")
        }else{
            resp.render('display',{empdata:data})
            
        }
    })
})



myrouter.post('/input',(req,resp)=>{
    connection.query('insert into Employee values(?,?,?,?)',[req.body.eid,req.body.ename,req.body.dept,req.body.sal],(err)=>{
        if (err) {
            resp.status(404).send("fails to insert data")
        }
        else{
            resp.redirect('/display')
        }
    })
})

module.exports=myrouter