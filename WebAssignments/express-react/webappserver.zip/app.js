var express= require('express')
var bodyparser= require('body-parser')
var path=require('path')
var app=express()
var routes=require('./routes/router.js')



app.use(bodyparser.urlencoded({extended:false}))
app.use(bodyparser.json())
app.use('/',routes)

app.listen(9000,(err)=>{
    if(err){
        console.log("port occupied")
    }
    console.log("server started at portno : 9000")
})

module.exports=app
