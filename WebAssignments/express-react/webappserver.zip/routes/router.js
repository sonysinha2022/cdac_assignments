var express = require('express')
var myrouter = express.Router()

var connection = require('../dbs/connecttodb')



myrouter.get('/product/getprod', (req, resp) => {
    connection.query('select * from product', (err, data, fileds) => {
        if (err) {
            resp.status(500).send("no data found");
        }
        else {
            resp.send(data)
        }
    })
})

myrouter.get('/product/getprod/:pid', (req, resp) => {
    connection.query('select * from product where pid=?',[req.params.pid], (err, data, fileds) => {
        if (err) {
            resp.status(500).send("no data found");
        }
        else {
            resp.send(data[0])
        }
    })
})

myrouter.post('/product/insertprod', (req, resp) => {
    connection.query('insert into product values (?,?,?,?)', [req.body.pid, req.body.pname, req.body.qty, req.body.price], (err,result) => {
        if (err) {
            resp.status(500).send('error while adding data')
        } else {
            resp.send('Added succesfully ')
        }
    })
})

myrouter.delete('/product/deleteprod/:pid',(req,resp)=>{
    connection.query('delete from product where pid=?',[req.params.pid],(err,result)=>{
        if (err) {
            resp.status(500).send('error while deleting data')
        }else{
            resp.send('Deleted succesfully ')
        }
    })
})

myrouter.put('/product/updateprod/:pid',(req,resp)=>{
    connection.query('update product set pname=?,qty=?,price=? where pid=? ',[req.body.pname,req.body.qty,req.body.price,req.params.pid],(err)=>{
        if (err) {
            resp.status(500).send('error while update')
        }
        else{
            resp.send('updated succesfully')
        }
    })
})

   

module.exports = myrouter