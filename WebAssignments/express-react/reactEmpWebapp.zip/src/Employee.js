export class Employee{
    constructor(eid,ename,dept,salary){
        this.eid=eid;
        this.ename=ename;
        this.dept=dept;
        this.salary=salary;
    }
}