import React from "react";

const HomeComp=()=>{
    return(
        <h1>Welcome To Employee Management</h1>
    )
}

export default HomeComp