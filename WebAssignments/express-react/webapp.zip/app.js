var express= require('express')
var bodyparser= require('body-parser')
var path=require('path')
var app=express()
var routes=require('./routes/router.js')

app.set("views",path.join(__dirname,"views"))
app.set("view engine","ejs")

app.use(bodyparser.urlencoded({extended:false}))
app.use('/',routes)

app.listen(9001,(err)=>{
    if(err){
        console.log("port occupied")
    }
    console.log("server started at portno : 9000")
})

module.exports=app
