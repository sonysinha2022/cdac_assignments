var express = require('express')
var myrouter = express.Router()

var connection = require('../dbs/connecttodb')

myrouter.use((req, resp, next) => {
    connection.query('create table product(pid int,pname varchar(30),qty int,price double(12,2))', (err) => {
        if (err) {
            //console.log(err.message)
        } else {
            console.log('table created')
        }
    })
    next();
})

myrouter.get('/getProduct', (req, resp) => {
    connection.query('select * from product', (err, data, fileds) => {
        if (err) {
            resp.status(500).send("no data found");
        }
        else {
            resp.render('index', { productd: data })
        }
    })
})

myrouter.get('/addproduct', (req, resp) => {
    resp.render('add-dt')
})

myrouter.post('/insertdt', (req, resp) => {
    connection.query('insert into product values (?,?,?,?)', [req.body.Pid, req.body.Pname, req.body.qty, req.body.price], (err) => {
        if (err) {
            resp.status(500).send('error while adding data')
        } else {
            resp.redirect('/getProduct')
        }
    })
})

myrouter.delete('/deleteprod/:pid',(req,resp)=>{
    const id = req.params.pid;
    connection.query('delete from product where pid=?',id,(err,select)=>{
        if (err) {
            resp.status(500).send('error while deleting data')
        }else{
            resp.redirect('/getProduct')
        }
    })
})

   

module.exports = myrouter