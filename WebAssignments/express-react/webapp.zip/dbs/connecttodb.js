var mysql=require('mysql')

var conectsql=mysql.createConnection({
    host:'127.0.0.1',
    user:'root',
    password:'root123',
    database: 'wpt',
    port: 3306
})

conectsql.connect((err)=>{
    if (err) {
        console.log(err.message)
    }
    
    console.log('conection to sql successfully')
})

module.exports=conectsql