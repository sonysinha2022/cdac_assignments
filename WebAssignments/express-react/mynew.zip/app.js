let express=require('express')
let app=express()
let router=require('./router/routers')
let path=require('path')
let bodyparser=require('body-parser')

app.set('views',path.join(__dirname,'views'))
app.set('view engine','ejs')


app.use(bodyparser.urlencoded({extended:false}))
app.use(bodyparser.json())
app.use('/',router)


app.listen(9000,(err)=>{
    if (err) {
        console.log("error occured")
    }
    else{
        console.log('server started at 9000')
    }
})

module.exports=app